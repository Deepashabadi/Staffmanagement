﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADOTNETPROJ2.Model
{
    class Staff
    {
        public int Id { get; set; }
        public string Name{get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public float Salary { get; set; }
        public int Experience { get; set; }

        public override string ToString()
        {
            string str = "";
            str += "NAME: " + Name;
            str += "EMAIL: " + Email;
            str += "PHONE: " + Phone;
            str += "SALARY: " + Salary.ToString();
            str += "EXPERIENCE: " + Experience.ToString();
            return str;
        }


    }
}
