﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ADOTNETPROJ2.Model
{
    class StaffLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["staffdb"].ConnectionString;

        public List<Staff> getStaffDetails()
        {
            List<Staff> li = new List<Staff>();
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                string sql = "select * from Staff";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Staff s = new Staff();
                    s.Id = Convert.ToInt32(reader.GetValue(0));
                    s.Name = reader.GetValue(1).ToString();
                    s.Email = reader.GetValue(2).ToString();
                    s.Phone = reader.GetValue(3).ToString();
                    s.Salary = float.Parse(reader.GetValue(4).ToString());
                    s.Experience = Convert.ToInt32(reader.GetValue(5));
                    li.Add(s);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);

            }
            finally
            {
                conn.Close();

            }
            return li;
        }

        public string AddData(Staff staff)
        {
            string message = "";
             
            string sql = String.Format("insert into Staff(NAME,EMAIL,PHONE,SALARY,EXPERIENCE) VALUES('{0} ','{1} ','{2} ',{3}, {4})",
            staff.Name, staff.Email, staff.Phone, staff.Salary, staff.Experience);
            
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                message = "the record inserted successfully :" + staff.ToString();

            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return message;
        }
        public DataSet GetSearchedData(int id)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from Staff where Id = " + id.ToString();

            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public string Updatedata(Staff s)
        {
            string message = "";
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("staffpro_update", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = s.Id;
                cmd.Parameters.Add("@name", SqlDbType.VarChar, 50).Value = s.Name;
                cmd.Parameters.Add("@email", SqlDbType.VarChar, 50).Value = s.Email;
                cmd.Parameters.Add("@phone", SqlDbType.VarChar, 10).Value = s.Phone;
                cmd.Parameters.Add("@salary", SqlDbType.Float).Value = s.Salary;
                cmd.Parameters.Add("@experience", SqlDbType.Int).Value = s.Experience;

                cmd.ExecuteNonQuery();
                message = "Data updated successfully";
            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }

            return message;
        }
        public string DeleteData(int id)
        {
            string message = "";
            SqlConnection conn = new SqlConnection(connStr);

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("PROC_DELSTAFF", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID ", SqlDbType.Int).Value = id;
                cmd.ExecuteNonQuery();
                message = "data deleted successfully";

            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }


            return message;
        }

    }
}
