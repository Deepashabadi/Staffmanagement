﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADOTNETPROJ2.Model;

namespace ADOTNETPROJ2
{
    public partial class SearchData : Form
    {
        public SearchData()
        {
            InitializeComponent();
        }

        private void Searchbtn_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtid.Value);
            StaffLogic ob = new StaffLogic();
            dataGridView1.DataSource = ob.GetSearchedData(id).Tables[0];
            dataGridView1.Visible = true;

        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ob = new Form1();
            ob.Show();
        }
    }
}
