﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADOTNETPROJ2.Model;

namespace ADOTNETPROJ2
{
    public partial class InsertForm : Form
    {
        public InsertForm()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }


        //SUBMIT Button
        private void label2_Click(object sender, EventArgs e)
        {
            Staff staff = new Staff();
            staff.Name = txtname.Text;
            staff.Email = txtemail.Text;
            staff.Phone = txtphone.Text;
            staff.Salary = float.Parse(txtsalary.Text);
            staff.Experience = Convert.ToInt32(txtexp.Text);

            StaffLogic ob = new StaffLogic();
            string message = ob.AddData(staff);
            MessageBox.Show(message);

        }

        //BACK Button
        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ob = new Form1();
            ob.Show();

        }
    }
}
