﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADOTNETPROJ2.Model;

namespace ADOTNETPROJ2
{
    public partial class Delete : Form
    {
        StaffLogic ob = new StaffLogic();
        public Delete()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }

        private void Srchbtn_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Dtxt.Value.ToString());
            DataSet res = ob.GetSearchedData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                string msg = ob.DeleteData(id);
                MessageBox.Show(msg);

            }
            else
            {
                MessageBox.Show("ID does not exist");
            }

        }

        private void Delete_Load(object sender, EventArgs e)
        {

        }
    }
    }

