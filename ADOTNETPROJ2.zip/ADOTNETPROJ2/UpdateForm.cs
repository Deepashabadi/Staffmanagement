﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADOTNETPROJ2.Model;

namespace ADOTNETPROJ2
{
    public partial class UpdateForm : Form
    {
        StaffLogic ob = new StaffLogic();
        public UpdateForm()
        {
            InitializeComponent();
        }

        private void UpdateForm_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            panel1.Visible = false;
            Updatebtn.Visible = false;
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }

        private void Searchbtn_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtbox.Value.ToString());
            DataSet res = ob.GetSearchedData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                panel1.Visible = true;
                txtname.Text = res.Tables[0].Rows[0]["name"].ToString();
                txtemail.Text = res.Tables[0].Rows[0]["email"].ToString();
                txtphone.Text = res.Tables[0].Rows[0]["phone"].ToString();
                txtsal.Text = res.Tables[0].Rows[0]["salary"].ToString();
                txtexp.Text = res.Tables[0].Rows[0]["experience"].ToString();
                Updatebtn.Visible = true;
               

            }
            else
            {
                MessageBox.Show("Record wrt the id does not exist");
            }
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            Staff s = new Staff();

            s.Id = Convert.ToInt32(txtbox.Value);
            s.Name = txtname.Text;
            s.Email = txtemail.Text;
            s.Phone = txtphone.Text;
            s.Salary = float.Parse(txtsal.Text.ToString());
            s.Experience = Convert.ToInt32(txtexp.Text.ToString());

            string msg = ob.Updatedata(s);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getStaffDetails();
            dataGridView1.Visible = true;
        }
    }
}

