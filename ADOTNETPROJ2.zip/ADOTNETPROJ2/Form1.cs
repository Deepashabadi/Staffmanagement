﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADOTNETPROJ2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Deatailbtn_Click(object sender, EventArgs e)
        {
            
            DetailsForm ob = new DetailsForm();
            ob.Show();
            this.Hide();
        }

        private void Insertbtn_Click(object sender, EventArgs e)
        {
            InsertForm ob = new InsertForm();
            ob.Show();
            this.Hide();

        }

        private void Searchbtn_Click(object sender, EventArgs e)
        {
            SearchData ob = new SearchData();
            ob.Show();
            this.Hide();

        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            UpdateForm ob = new UpdateForm();
            ob.Show();
            this.Hide();
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            Delete ob = new Delete();
            ob.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
